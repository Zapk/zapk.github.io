exec("./updater.cs");

// Adds the key sounds to the cache, so you don't download them upon joining.
function PlayPiano_SyncContentCache()
{
	if($PlayPiano::SyncedCache)
		return;

	$PlayPiano::SyncedCache = true;

	%pattern = "Add-Ons/System_PlayablePiano/res/sfx/*.wav";
	%file = findFirstFile(%pattern);

	while(isFile(%file))
	{
		addFileToCache(%file);

		%file = findNextFile(%pattern);
	}
}

schedule(200, 0, PlayPiano_SyncContentCache);

if(!isObject(PianoWhiteKeyProfile)) new GuiControlProfile(PianoWhiteKeyProfile)
{
	fontType = "Impact";
	fontSize = "18";
	fontColor = "50 50 50 255";
	justify = "center";
};

if(!isObject(PianoBlackKeyProfile)) new GuiControlProfile(PianoBlackKeyProfile : PianoWhiteKeyProfile)
{
	fontColor = "200 200 200 255";
};

if(!isObject(PianoGui))
{
	exec("./gui/PianoGui.gui");
}

function clientCmdBLT_Piano_Handshake()
{
	commandToServer('BLT_Piano_Handshake');
}

function _PianoKey(%bind, %sound, %img, %label, %x)
{
	$PianoBind[ $PianoKeys ] = %bind;
	$PianoLabel[ $PianoKeys ] = %label;
	$PianoSound[ $PianoKeys ] = %sound;
	$PianoImage[ $PianoKeys ] = %img;
	$PianoPos[ $PianoKeys ] = %x;

	$PianoKeys++;
}

function _PianoChangeMode()
{
	$PianoMode = !$PianoMode;
	_PianoGuiBuild();
}

function _PianoGuiBuild()
{
	$PianoMode = !!$PianoMode;
	$PianoKeys = 0;

	if(!$PianoMode)
	{
		_PianoKey("a", "a15", "left", "A", 19);
		_PianoKey("s", "a16", "middle", "S", 44);
		_PianoKey("d", "a17", "right", "D", 69);
		_PianoKey("f", "a18", "left", "F", 94);
		_PianoKey("g", "a19", "leftmid", "G", 119);
		_PianoKey("h", "a20", "rightmid", "H", 144);
		_PianoKey("j", "a21", "right", "J", 169);
		_PianoKey("k", "a22", "left", "K", 194);
		_PianoKey("l", "a23", "middle", "L", 219);
		_PianoKey(";", "a24", "right", ";", 244);
		_PianoKey("'", "a25", "full", "'", 269);

		_PianoKey("w", "b11", "top", "W", 33);
		_PianoKey("e", "b12", "top", "E", 64);
		_PianoKey("t", "b13", "top", "T", 108);
		_PianoKey("y", "b14", "top", "Y", 136);
		_PianoKey("u", "b15", "top", "U", 164);
		_PianoKey("o", "b16", "top", "O", 208);
		_PianoKey("p", "b17", "top", "P", 239);

		%pianoExtent = "313 197";
		%pianoBitmap = "Add-Ons/System_PlayablePiano/res/img/piano";
	}
	else
	{
		_PianoKey("1", "a1", "left", "1", 19);
		_PianoKey("shift 1", "b1", "top", "!", 33);
		_PianoKey("2", "a2", "middle", "2", 44);
		_PianoKey("shift 2", "b2", "top", "@", 64);
		_PianoKey("3", "a3", "right", "3", 69);
		_PianoKey("4", "a4", "left", "4", 94);
		_PianoKey("shift 4", "b3", "top", "$", 108);
		_PianoKey("5", "a5", "leftmid", "5", 119);
		_PianoKey("shift 5", "b4", "top", "%", 136);
		_PianoKey("6", "a6", "rightmid", "6", 144);
		_PianoKey("shift 6", "b5", "top", "^", 164);
		_PianoKey("7", "a7", "right", "7", 169);
		_PianoKey("8", "a8", "left", "8", 194);
		_PianoKey("shift 8", "b6", "top", "*", 208);
		_PianoKey("9", "a9", "middle", "9", 219);
		_PianoKey("shift 9", "b7", "top", "(", 239);
		_PianoKey("0", "a10", "right", "0", 244);
		_PianoKey("Q", "a11", "left", "q", 269);
		_PianoKey("shift q", "b8", "top", "Q", 283);
		_PianoKey("W", "a12", "leftmid", "w", 294);
		_PianoKey("shift w", "b9", "top", "W", 310);
		_PianoKey("E", "a13", "rightmid", "e", 319);
		_PianoKey("shift e", "b10", "top", "E", 339);
		_PianoKey("R", "a14", "right", "r", 344);
		_PianoKey("T", "a15", "left", "t", 369);
		_PianoKey("shift t", "b11", "top", "T", 383);
		_PianoKey("Y", "a16", "middle", "y", 394);
		_PianoKey("shift y", "b12", "top", "Y", 414);
		_PianoKey("U", "a17", "right", "u", 419);
		_PianoKey("I", "a18", "left", "i", 444);
		_PianoKey("shift i", "b13", "top", "I", 458);
		_PianoKey("O", "a19", "leftmid", "o", 469);
		_PianoKey("shift o", "b14", "top", "O", 486);
		_PianoKey("P", "a20", "rightmid", "p", 494);
		_PianoKey("shift p", "b15", "top", "P", 514);
		_PianoKey("A", "a21", "right", "a", 519);
		_PianoKey("S", "a22", "left", "s", 544);
		_PianoKey("shift s", "b16", "top", "S", 558);
		_PianoKey("D", "a23", "middle", "d", 569);
		_PianoKey("shift d", "b17", "top", "D", 590);
		_PianoKey("F", "a24", "right", "f", 594);
		_PianoKey("G", "a25", "left", "g", 619);
		_PianoKey("shift g", "b18", "top", "G", 633);
		_PianoKey("H", "a26", "leftmid", "h", 644);
		_PianoKey("shift h", "b19", "top", "H", 661);
		_PianoKey("J", "a27", "rightmid", "j", 669);
		_PianoKey("shift j", "b20", "top", "J", 690);
		_PianoKey("K", "a28", "right", "k", 694);
		_PianoKey("L", "a29", "left", "l", 719);
		_PianoKey("shift l", "b21", "top", "L", 734);
		_PianoKey("Z", "a30", "middle", "z", 744);
		_PianoKey("shift z", "b22", "top", "Z", 765);
		_PianoKey("X", "a31", "right", "x", 769);
		_PianoKey("C", "a32", "left", "c", 794);
		_PianoKey("shift c", "b23", "top", "C", 809);
		_PianoKey("V", "a33", "leftmid", "v", 819);
		_PianoKey("shift v", "b24", "top", "V", 837);
		_PianoKey("B", "a34", "rightmid", "b", 844);
		_PianoKey("shift b", "b25", "top", "B", 865);
		_PianoKey("N", "a35", "right", "n", 869);
		_PianoKey("M", "a36", "full", "m", 894);

		%pianoExtent = "937 197";
		%pianoBitmap = "Add-Ons/System_PlayablePiano/res/img/piano_large";
	}

	PianoBitmap.getGroup().extent = %pianoExtent;
	PianoBitmap.extent = %pianoExtent;
	PianoBitmap.setBitmap(%pianoBitmap);

	PianoBitmap.getGroup().center();

	PianoText1.centerX();
	PianoText2.centerX();

	PianoText2.setText("CONTROL FOR" SPC ($PianoMode ? "BASIC" : "ADVANCED") SPC "MODE");

	if(isObject(PianoMap))
	{
		PianoMap.delete();
	}

	new ActionMap(PianoMap);

	%bp = PianoBitmap.getID();

	if(!isObject(%bp))
	{
		return error("No PianoBitmap!");
	}

	%bp.deleteAll();

	PianoMap.bind(keyboard, getField(moveMap.getBinding("Jump"), 1), Jump);
	PianoMap.bindCmd(keyboard, "lcontrol", "", "_PianoChangeMode();");
	PianoMap.bindCmd(keyboard, "rcontrol", "", "_PianoChangeMode();");

	for(%i = 0; %i < $PianoKeys; %i++)
	{
		%img = $PianoImage[%i];
		%extent = (%img $= "top" ? "15 70" : "24 125");

		%textent = (%img $= "top" ? "15 28" : "24 55");
		%textprofile = (%img $= "top" ? PianoBlackKeyProfile : PianoWhiteKeyProfile);
		%texty = (%img $= "top" ? 55 : 110);

		PianoMap.bindCmd(keyboard, $PianoBind[%i], "_PianoDown(" @ %i @ ");", "_PianoUp(" @ %i @ ");");

		%btn = new GuiBitmapCtrl("_PianoBitmap" @ %i)
		{
			position = $PianoPos[%i] SPC 30;
			extent = %extent;
			bitmap = "Add-Ons/System_PlayablePiano/res/img/piano_note_" @ %img @ "_d";
			visible = false;
		};

		%text = new GuiTextCtrl()
		{
			position = $PianoPos[%i] SPC %texty;
			text = $PianoLabel[%i];
			extent = %textent;
			profile = %textprofile;
		};

		%bp.add(%btn);
		%bp.add(%text);
	}

	PianoMap.push();
}

function _PianoDown(%i)
{
	nameToID("_PianoBitmap" @ %i).setVisible(true);

	commandToServer('BLT_Piano_Press', $PianoSound[ %i ]);
}

function _PianoUp(%i)
{
	nameToID("_PianoBitmap" @ %i).setVisible(false);
}

function clientCmdBLT_Piano_SetActive(%val)
{
	if(%val)
	{
		_PianoGuiBuild();
		Canvas.pushDialog(PianoGui);

		moveMap.pop();
	}

	else
	{
		moveMap.push();

		if(isObject(PianoMap))
			 PianoMap.pop();

		Canvas.popDialog(PianoGui);
	}
}
