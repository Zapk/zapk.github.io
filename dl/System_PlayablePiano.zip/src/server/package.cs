package BLT_Piano
{
	function gameConnection::spawnPlayer(%this)
	{
		Parent::spawnPlayer(%this);
		%this.hasPianoClient = false;

		commandToClient(%this, 'BLT_Piano_Handshake');
		commandToClient(%this, 'BLT_Piano_SetActive', false);
	}

	function fxDTSBrick::onActivate(%this, %obj, %client, %pos, %vec)
	{
		%name = %this.getName();
		%db = %this.getDatablock();

		if( %db.canSit && !isObject(%hit.sittingPlayer) && !%obj.isChairSitting )
		{
			// Mount them to the 'chair'.
			%obj.setChairSit(1, %this);
		}
		if( %db.canPiano && !isObject(%hit.playingPlayer) && !%obj.isAtPiano )
		{
			// Send them into piano mode.
			%obj.setPiano(1, %this);

			if(!%client.hasPianoClient)
			{
				%link = "zapk.github.io/dl/System_PlayablePiano.zip";

				messageClient(%client, 'MsgError', '\c0You cannot play the piano because you do not have \c3System_PlayablePiano\c0!');
				messageClient(%client, '', '\c0You can get \c3System_PlayablePiano \c0here: <a:%1>%1</a>.', %link);

				// No client? Eject them.
				%obj.getDatablock().onTrigger(%obj, 2, true);
			}
		}
		else
		{
			return Parent::onActivate(%this, %obj, %client, %pos, %vec);
		}
	}

	function Armor::onTrigger(%this, %obj, %slot, %val)
	{
		if(%slot == 2)
		{
			if(%obj.isAtPiano)
			{
				%obj.setPiano(false, %obj.playingPiano);
			}

			if(%obj.isChairSitting)
			{
				%obj.setChairSit(false, %obj.sittingAt);
			}
		}

		Parent::onTrigger(%this, %obj, %slot, %val);
	}
};

activatePackage(BLT_Piano);