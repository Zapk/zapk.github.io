exec("./package.cs");

datablock fxDTSBrickData(brickPianoData)
{
	brickFile = "Add-Ons/System_PlayablePiano/res/blb/piano.blb";
	iconName = "Add-Ons/System_PlayablePiano/res/blb/piano";
	category = "Special";
	subCategory = "Instruments";
	uiName = "Piano";

	canPiano = true;
};

datablock fxDTSBrickData(brickPianoBenchData)
{
	brickFile = "Add-Ons/System_PlayablePiano/res/blb/piano bench.blb";
	iconName = "Add-Ons/System_PlayablePiano/res/blb/piano bench";
	category = "Special";
	subCategory = "Instruments";
	uiName = "Piano Bench";

	canSit = true;
};

function serverCmdBLT_Piano_Handshake(%this)
{
	%this.hasPianoClient = true;
}

function Player::setSpeedFactor(%this, %f)
{
	%db = %this.getDatablock();

	%this.setMaxForwardSpeed( %db.maxForwardSpeed * %f );
	%this.setMaxBackwardSpeed( %db.maxBackwardSpeed * %f );
	%this.setMaxSideSpeed( %db.maxSideSpeed * %f );
	%this.setMaxCrouchForwardSpeed( %db.maxForwardCrouchSpeed * %f );
	%this.setMaxCrouchBackwardSpeed( %db.maxBackwardCrouchSpeed * %f );
	%this.setMaxCrouchSideSpeed( %db.maxSideCrouchSpeed * %f );
}

function generatePianoSoundDatablocks()
{
	%pattern = "Add-Ons/System_PlayablePiano/res/sfx/*.wav";
	%file = findFirstFile(%pattern);

	while(isFile(%file))
	{
		%base = fileBase(%file);
		%name = "BLTS_P_" @ %base;

		if(!isObject(%name))
		{
			datablock AudioProfile(BLTS_TEMP)
			{
				fileName = %file;
				description = AudioClosest3d;
				preload = true;
			};
	
			BLTS_TEMP.setName(%name);
		}

		%file = findNextFile(%pattern);
	}
}

generatePianoSoundDatablocks();

function serverCmdBLT_Piano_Press(%this, %sound)
{
	if(!isObject(%this.player)) return;
	if(!%this.player.isAtPiano) return;

	%sound = nameToID("BLTS_P_" @ %sound);
	if(!isObject(%sound)) return;

	%time = getSimTime();
	%diff = %time - %this.lastPianoPress;

	ServerPlay3D(%sound, %this.player.getPosition());

	if(%diff > 750)
		%this.player.playThread(1, "activate");
	else
		%this.player.playThread(1, "activate2");

	if(%diff < 100)
		%this.player.playThread(2, "plant");

	%this.lastPianoPress = %time;
}

function Player::setChairSit(%this, %bool, %brick)
{
	if(%bool)
	{
		if(!isObject(%brick) || isObject(%brick.sittingPlayer))
		{
			return;
		}

		%brick.sittingPlayer = %this;
		%this.sittingAt = %brick;

		%center = %brick.getWorldBoxCenter();
		%heightAdd = %brick.getDatablock().brickSizeZ * 0.1;
		%sitAt = VectorAdd(%center, "0 0" SPC %heightAdd);

		%sitAt = VectorAdd(%sitAt, VectorScale( %brick.getForwardVector(), %brick.getDatablock().sitForwardScale / 2 ));

		%rot = getWords(%this.getTransform(), 3, 6);
		%this.setTransform(%sitAt SPC %rot);

		%this.playThread(0, "sit");

		%this.setSpeedFactor(0.0);
		%this.setVelocity("0 0 0");
	}
	else
	{
		if(isObject(%brick))
		{
			%brick.sittingPlayer = -1;
			%this.sittingAt = -1;
		}

		%this.playThread(0, "root");

		%this.setSpeedFactor(1.0);
	}

	%this.isChairSitting = !!%bool;
}

function Player::setPiano(%this, %bool, %brick)
{
	if(%bool)
	{
		if(!isObject(%brick) || isObject(%brick.playingPlayer))
		{
			return;
		}

		%brick.playingPlayer = %this;
		%this.playingPiano = %brick;

		%this.setSpeedFactor(0.0);

		commandToClient(%this.client, 'BLT_Piano_SetActive', true);
	}
	else
	{
		if(isObject(%brick))
		{
			%brick.playingPlayer = -1;
			%this.playingPiano = -1;
		}

		%this.setSpeedFactor(1.0);

		commandToClient(%this.client, 'BLT_Piano_SetActive', false);
	}

	%this.isAtPiano = !!%bool;
}