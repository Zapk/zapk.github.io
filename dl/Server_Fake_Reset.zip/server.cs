// Server_Fake_Reset

function serverCmdOnMinigameReset(%this)
{
	if(!%this.isAdmin)
	{
		messageClient(%this, '', '\c7This is an admin-only command.');
		return;
	}

	for(%i = 0; %i < MainBrickGroup.getCount(); %i++)
	{
		%group = MainBrickGroup.getObject(%i);

		for(%j = 0; %j < %group.getCount(); %j++)
		{
			%group.getObject(%j).onMinigameReset();
		}
	}

	messageAll('', '\c3%1 \c2called a fake minigame reset.', %this.getPlayerName());
}