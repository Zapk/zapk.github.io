//- numberFormat (formats a number with commas)
function numberFormat(%number)
{
   if(strLen(%number) <= 3)
      return %number;

   %k = 0;
   for(%i=strLen(%number)-1;%i>0;%i--)
   {
      if(%k%3 $= 2)
         %number = getSubStr(%number,0,%i)@","@getSubStr(%number,%i,1000);
      %k++;
   }
   return %number;
}

//- GuiControl::centerX (Centers %this inside %parent horizontally)
function GuiControl::centerX(%this,%parent)
{
   if(isObject(%parent))
   {
      %maxArea = getWord(%parent.extent,0);
      %width = getWord(%this.extent,0);

      %xPosition = (%maxArea/2)-(%width/2);
      if(%parent $= %this.getGroup())
         %this.position = (%xPosition+getWord(%parent.position,0)) SPC getWord(%this.position,1);
      else
         %this.position = (%xPosition+getWord(%parent.getCanvasPosition(),0)) SPC getWord(%this.getCanvasPosition(),1);
   }
   else
   {
      %parent = %this.getGroup();
      %maxArea = getWord(%parent.extent,0);
      %width = getWord(%this.extent,0);

      %xPosition = (%maxArea/2)-(%width/2);
      %this.position = %xPosition SPC getWord(%this.position,1);
   }
}

//- GuiControl::centerY (Centers %this inside %parent vertically)
function GuiControl::centerY(%this,%parent)
{
   if(isObject(%parent))
   {
      %maxArea = getWord(%parent.extent,1);
      %height = getWord(%this.extent,1);

      %yPosition = (%maxArea/2)-(%height/2);
      if(%parent $= %this.getGroup())
         %this.position = getWord(%this.position,0) SPC (%yPosition+getWord(%parent.position,1));
      else
         %this.position = getWord(%this.getCanvasPosition(),0) SPC (%yPosition+getWord(%parent.getCanvasPosition(),1));
   }
   else
   {
      %parent = %this.getGroup();
      %maxArea = getWord(%parent.extent,1);
      %height = getWord(%this.extent,1);

      %yPosition = (%maxArea/2)-(%height/2);
      %this.position = getWord(%this.position,0) SPC %yPosition;
   }
}

function GuiControl::center(%this,%parent)
{
   %this.centerX(%parent);
   %this.centerY(%parent);
}
