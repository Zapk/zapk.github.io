$BLTC::src = "Add-Ons/Client_Blockland_Tower/src/";
$BLTC::lib = "Add-Ons/Client_Blockland_Tower/lib/";
$BLTC::res = "Add-Ons/Client_Blockland_Tower/res/";

function BLTC_Reload()
{
	exec("./client.cs");
}

////////////////////////////////////////////////////////////////

exec($BLTC::lib @ "tango.cs");
exec($BLTC::lib @ "rtbFunctions.cs");
exec($BLTC::lib @ "jettison.cs");

////////////////////////////////////////////////////////////////

function clientCmdBLT_Authenticate(%allPackages)
{
	if($BLTC::WithinSession)
	{
		return;
	}

	if(!ServerConnection.isLocal() && !ServerConnection.isLan())
	{
		%ip = ServerConnection.getAddress();
		%ip = strreplace(%ip, ".", "_");
		%ip = strreplace(%ip, ":", "X");

		%serverObject = $ServerSO[ $ServerSOFromIP[ %ip ] ];

		if(!isObject(%serverObject))
		{
			return;
		}

		%gameMode = %serverObject.map;

		// Simple check for GameMode names. Yes, servers can change theirs; it would say so in the list, however, warning people.
		if(%gameMode !$= "Blockland Tower" && strPos(%gameMode, "BLT: ") != 0)
		{
			%title = "Blockland Tower";
			%body = "It appears the server you are on attempted to authenticate with Client_Blockland_Tower, but it doesn't seem genuine. Careful now.\n\nWould you like to disconnect?";
			%cmd = "disconnect();";

			MessageBoxYesNo(%title, %body, %cmd);

			return;
		}
	}

	$BLTC::WithinSession = true;

	if(%allPackages)
	{
		BLTC_SetPackagesActive(true);
	}
	else
	{
		activatePackage(BLTC_Package_Chat);
		activatePackage(BLTC_Package_Notifications);
	}
}

$BLTC::PackageCount = 0;

function BLTC_RegisterPackage(%name)
{
	$BLTC::Package[$BLTC::PackageCount] = %name;
	$BLTC::PackageCount++;

	if($BLTC::WithinSession)
	{
		activatePackage(%name);
	}
}

function BLTC_SetPackagesActive(%isActive)
{
	for(%i = 0; %i < $BLTC::PackageCount; %i++)
	{
		%package = $BLTC::Package[%i];

		if(%isActive)
		{
			activatePackage(%package);
		}
		else
		{
			deactivatePackage(%package);
		}
	}
}

////////////////////////////////////////////////////////////////

exec($BLTC::src @ "profiles.cs");

if(!isObject(TowerKeyGui))
	exec($BLTC::res @ "gui/TowerKeyGui.gui");
if(!isObject(TowerHUD))
	exec($BLTC::res @ "gui/TowerHUD.gui");
if(!isObject(TowerInventory))
	exec($BLTC::res @ "gui/TowerInventory.gui");
if(!isObject(TowerLoading))
	exec($BLTC::res @ "gui/TowerLoading.gui");
if(!isObject(TowerShop))
	exec($BLTC::res @ "gui/TowerShop.gui");
if(!isObject(TowerSuites))
	exec($BLTC::res @ "gui/TowerSuites.gui");
if(!isObject(TowerPiano))
	exec($BLTC::res @ "gui/TowerPiano.gui");
if(!isObject(TowerPlastic))
	exec($BLTC::res @ "gui/TowerPlastic.gui");

////////////////////////////////////////////////////////////////

exec($BLTC::src @ "cache.cs");
exec($BLTC::src @ "loading.cs");
exec($BLTC::src @ "notifications.cs");
exec($BLTC::src @ "hud.cs");
exec($BLTC::src @ "chat.cs");
exec($BLTC::src @ "key.cs");
exec($BLTC::src @ "shop.cs");
exec($BLTC::src @ "suites.cs");
exec($BLTC::src @ "drunk.cs");
exec($BLTC::src @ "inventory.cs");
exec($BLTC::src @ "soundscapes.cs");
exec($BLTC::src @ "piano.cs");
exec($BLTC::src @ "misc.cs");

////////////////////////////////////////////////////////////////

if(isPackage(BLTC_Package_Kernel))
{
	deactivatePackage(BLTC_Package_Kernel);
}

package BLTC_Package_Kernel
{
	function GameConnection::setConnectArgs( %a, %b, %c, %d, %e, %f, %g, %h, %i, %j )
	{
		%j = trim( %j @ "\tBLT " @ $BLTC::VersionInteger );

		Parent::setConnectArgs(%a, %b, %c, %d, %e, %f, %g, %h, %i, %j);
	}

	function disconnectedCleanup(%doReconnect)
	{
		%parent = Parent::disconnectedCleanup(%doReconnect);

		if(isFunction("BLTC_Hook_Cleanup"))
			BLTC_Hook_Cleanup();

		BLTC_SetPackagesActive(false);
		$BLTC::WithinSession = false;

		return %parent;
	}

	function BLT_PlasticBuyField::setValue( %this, %string )
	{
		Parent::setValue( %this, %string );
		echo(%string);
	}
};

activatePackage(BLTC_Package_Kernel);

function BLTC_LoadVersion()
{
	%file = "Add-Ons/Client_Blockland_Tower/version.json";

	if(jettisonReadFile(%file))
	{
		error("Failed to parse JSON: " @ $JSON::Error);
		return;
	}

	%version = $JSON::Value.value["version"];

	$BLTC::VersionString = %version;
	$BLTC::VersionInteger = mFloor( strreplace( %version, ".", "" ) );

	if($JSON::Type $= "object")
	{
		$JSON::Value.delete();
	}
}

if($BLTC::VersionString $= "")
{
	schedule(0, 0, BLTC_LoadVersion);
}
