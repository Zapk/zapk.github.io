function BLTC_Reload()
{
	exec("./client.cs");
}

function BLTC_LoadVersion()
{
	%file = "Add-Ons/Client_Blockland_Tower/clientversion.txt";

	if(!isFile(%file))
	{
		warn(%file SPC "doesn't exist!");
		return;
	}

	%fo = new fileObject();

	%fo.openForRead(%file);

	%version = "ERROR";

	while(!%fo.isEOF())
	{
		%line = %fo.readLine();

		if(%line !$= "")
		{
			%version = %line;
		}
	}

	$BLTC::VersionString = %version;
	$BLTC::VersionInteger = mFloor( strreplace( %version, ".", "" ) );

	%fo.close();
	%fo.delete();
}

if($BLTC::VersionString $= "")
{
	schedule(0, 0, BLTC_LoadVersion);
}

exec("./lib/Support_TCPClient.cs");
exec("./lib/tango.cs");

exec("./src/profiles.cs");
exec("./src/updates.cs");

if(!isObject(TowerKeyGui)) exec("./res/gui/TowerKeyGui.gui");
if(!isObject(TowerHUD)) exec("./res/gui/TowerHUD.gui");

if(!isObject(TowerShop)) exec("./res/gui/TowerShop.gui");

if(!isObject(PianoGui)) exec("./res/gui/PianoGui.gui");

if(!isObject(TowerUpdateAvailable)) exec("./res/gui/TowerUpdateAvailable.gui");
if(!isObject(TowerUpdating)) exec("./res/gui/TowerUpdating.gui");
if(!isObject(TowerUpdateDone)) exec("./res/gui/TowerUpdateDone.gui");

if(TowerKeyGui.getGroup().getName() !$= "PlayGui")
{
	PlayGui.add(TowerKeyGui);
}

exec("./src/rtbFunctions.cs");

exec("./src/main.cs");
exec("./src/soundscapes.cs");
exec("./src/piano.cs");
