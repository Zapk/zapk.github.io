if(isPackage(BLTC_Package_HUD))
{
	deactivatePackage(BLTC_Package_HUD);
}

package BLTC_Package_HUD
{
	function BLTC_Hook_Cleanup()
	{
		Parent::BLTC_Hook_Cleanup();

		clientCmdBLT_HUD_SetActive(false);
	}

	function resetCanvas()
	{
		%parent = Parent::resetCanvas();

		%this = nameToID( TowerHUD );

		if( isObject( %this ) )
		{
			%this.positionHUD();
		}

		return %parent;
	}

	function TowerHUD::positionHUD(%this)
	{
		if( %this.getGroup().getName() !$= "PlayGui" )
		{
			return;
		}

		%y = getWord( getRes(), 1 ) - getWord( %this.getExtent(), 1 ) - 6;

		%this.tangoSetPosition( 0 SPC %y );
	}

	function clientCmdBLT_HUD_SetActive(%val)
	{
		if( %val && TowerHUD.getGroup().getName() !$= "PlayGui" )
		{
			PlayGui.add( TowerHUD );
			TowerHUD.positionHUD();
		}

		else if( !%val && TowerHUD.getGroup().getName() !$= "GuiGroup" )
		{
			PlayGui.remove( TowerHUD );
			GuiGroup.add( TowerHUD );
		}
	}

	function TowerHUD::updateText(%this)
	{
		BLTC_HudText1.setText("<shadow:1:1><color:ffffff><font:Oswald:36>" @ numberFormat(%this.dVal["c"]) @ " <font:Oswald:18>BLC");
		BLTC_HudText2.setText("<shadow:1:1><color:ffffff><font:Oswald:18>" @ %this.dVal["l"]);
	}

	function clientCmdBLT_UpdateValue(%type, %val)
	{
		if(%type $= "") return;

		TowerHUD.dVal[%type] = %val;
		TowerHUD.updateText();
	}

};

BLTC_RegisterPackage(BLTC_Package_HUD);
