function clientCmdBLT_KeyText(%string, %msKeep)
{
	if(TowerKeyGui.getGroup().getName() !$= "PlayGui")
	{
		PlayGui.add(TowerKeyGui);
	}
	
	%msKeep = mClamp(%msKeep, 100, 10000);

	cancel($BLT::KeyDrop);
	$BLT::KeyDrop = schedule(%msKeep, 0, BLT_KeyDrop);

	TowerKeyGui.center();
	TowerKeyText.center();

	TowerKeyText.setText(%string);
	TowerKeyGui.setVisible(true);
}

function BLT_KeyDrop()
{
	cancel($BLT::KeyDrop);

	TowerKeyGui.setVisible(false);
}