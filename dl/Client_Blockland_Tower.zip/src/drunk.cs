if(isPackage(BLTC_Package_Drunk))
{
	deactivatePackage(BLTC_Package_Drunk);
}

package BLTC_Package_Drunk
{
	function setDrunkLevel(%level)
	{
		cancel($drunkLoop);

		%level = mClampF(%level, 0, 1);

		$drunkYaw = 0;
		$drunkPitch = 0;

		$drunkLeft = 0;

		clientCmdSetVignette(1, "0 " @ %level @ " 0 0");

		$drunkLevel = %level;

		if(%level > 0)
		{
			BLTC_DrunkLoop();
		}
		else
		{
			moveLeft(0);
			moveRight(0);
			setFov($pref::Player::defaultFov);
		}
	}

	function BLTC_DrunkLoop()
	{
		cancel($drunkLoop);

		if(!isObject(ServerConnection)) return;

		%lvl = $drunkLevel;

		yaw( mCos($drunkYaw += 0.05) + mSin($drunkYaw) * mSin($drunkYaw / 20) * %lvl );
		pitch( mCos($drunkPitch += 0.05) * mSin($drunkPitch) * mSin($drunkPitch / 20) * %lvl );

		//%left = mSin($drunkLeft += 0.05) * %lvl * 0.4;
		//moveLeft( %left );

		setFov($pref::Player::defaultFov + (%lvl * 50));

		$drunkLoop = schedule(33, 0, BLTC_DrunkLoop);
	}
};

BLTC_RegisterPackage(BLTC_Package_Drunk);
