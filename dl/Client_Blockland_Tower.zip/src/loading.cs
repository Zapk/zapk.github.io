if(isPackage(BLTC_Package_Loading))
{
	deactivatePackage(BLTC_Package_Loading);
}

package BLTC_Package_Loading
{
	function BLTC_Hook_Cleanup()
	{
		Parent::BLTC_Hook_Cleanup();

		clientCmdBLT_SetLoadingScreen("");
	}

	function clientCmdBLT_SetLoadingScreen(%bg, %title, %author, %info)
	{
		%file = "Add-Ons/Client_Blockland_Tower/res/img/loadscreens/" @ %bg @ ".png";

		if(isFile(%file))
		{
			LOAD_MapPicture.setBitmap(%file);
			if(isObject(LOAD_TipSwatch)) LOAD_TipSwatch.setVisible(false);
			Canvas.pushDialog(TowerLoading);
			TowerLTitle.setText("<color:ffffff><font:Oswald:36>" @ %title @ " <font:Oswald:22>by " @ %author);
			TowerLInfo.setText("<color:ffffff><font:Oswald:36>" @ %info);
		}
		else
		{
			LOAD_MapPicture.setBitmap("base/client/ui/loadingBG.png");
			if(isObject(LOAD_TipSwatch)) LOAD_TipSwatch.setVisible(true);
			Canvas.popDialog(TowerLoading);
		}
	}

	function clientCmdBLT_SetLoadingUserInfo(%name, %blc, %lastseen, %playtime)
	{
		%name = StripMLControlChars(%name);
		%lastseen = StripMLControlChars(%lastseen);

		TowerLUsername.setText("<color:ffffff><font:Oswald:42>" @ %name);
		TowerLBLC.setText("<color:ffffff><font:Oswald:24>" @ numberFormat(%blc));
		TowerLLastSeen.setText("<color:dddddd><font:Oswald:17>LAST SEEN<br><color:ffffff><font:Oswald:24>" @ %lastseen);
		TowerLPlaytime.setText("<color:dddddd><font:Oswald:17>PLAYTIME<br><color:ffffff><font:Oswald:24>" @ numberFormat(%playtime) @ " hour" @ (%playtime == 1 ? "" : "s"));
	}

};

BLTC_RegisterPackage(BLTC_Package_Loading);
