function TowerShop::clean(%this)
{
	TowerShopWindow.setText("Shop");
	TowerShopList.clear();
	TowerShopText.setText("<font:Oswald:32>No Item Selected");
	TowerShopBuyButton.setVisible(false);
	TowerShopImage.setBitmap("Add-Ons/Client_Blockland_Tower/res/img/items/unknown.png");
	TowerShopAlert.tangoSetPosition("370 490");
}

function TowerShop::open(%this, %title)
{
	BLTC_AnimateInventory(1);
	%this.clean();
	TowerShopWindow.setText(%title);
	Canvas.pushDialog(%this);

	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/hover.wav"));
}

function clientCmdBLT_Shop_Open(%title)
{
	TowerShop.open(%title);
}

function TowerShop::close(%this)
{
	Canvas.popDialog(%this);
	%this.clean();
	commandToServer('Shop_Cancel');

	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/hover.wav"));
	BLTC_AnimateInventory(0);
}

function TowerShop::slideAnimation(%this)
{
	%e = quart;
	%t = 250;

	TowerShopSide1.extent = "260 435";
	TowerShopSide1.tangoScaleTo("260 255", %t, %e);

	TowerShopSide1.getObject(0).extent = "244 419";
	TowerShopSide1.getObject(0).tangoScaleTo("244 239", %t, %e);

	TowerShopSide2.extent = "260 0";
	TowerShopSide2.tangoScaleTo("260 170", %t, %e);

	TowerShopSide2.tangoSetPosition("370 470");
	TowerShopSide2.tangoMoveTo("370 300", %t, %e);
}

function TowerShop::addShopItem(%this, %cost, %name, %item, %desc)
{
	%list = TowerShopList;

	%row = numberFormat(%cost) SPC "BLC";
	%row = %row @ "\t" @ %name;
	%row = %row @ "\t" @ %item;
	%row = %row @ "\t" @ %desc;

	%list.addRow(%list.rowCount(), %row);
}

function clientCmdBLT_Shop_AddItem(%cost, %name, %item, %desc)
{
	TowerShop.addShopItem(%cost, %name, %item, %desc);
}

function TowerShop::clickList(%this)
{
	%idx = TowerShopList.getSelectedID();

	%row = TowerShopList.getRowText(%idx);

	%cost = getField(%row, 0);
	%name = getField(%row, 1);
	%item = getField(%row, 2);
	%desc = getField(%row, 3);

	%btmp = "Add-Ons/Client_Blockland_Tower/res/img/items/" @ %item @ ".png";

	TowerShopText.setText("<font:Oswald:32>" @ %name @ " <font:Oswald:18>" @ %cost @ "<br><font:Oswald Light:30>" @ %desc);

	if(isFile(%btmp))
		TowerShopImage.setBitmap(%btmp);
	else
		TowerShopImage.setBitmap("Add-Ons/Client_Blockland_Tower/res/img/items/unknown.png");

	%this.selectedItem = %item;

	TowerShopBuyButton.setVisible(true);

	%this.slideAnimation();

	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/select.wav"));
}

function TowerShop::clickBuy(%this)
{
	commandToServer('Shop_Buy', %this.selectedItem);

	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/select.wav"));
}

function TowerShop::alert(%this, %text)
{
	TowerShopAlertText.setText("<font:Oswald Light:30>" @ %text);
	TowerShopAlert.setVisible(true);

	TowerShopAlert.tangoSetPosition("370 490");
	TowerShopAlert.tangoMoveTo("370 35", 250, elastic);

	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/blip1.wav"));
}

function clientCmdBLT_Shop_Alert(%text)
{
	TowerShop.alert(%text);
}

function TowerShop::clickDismiss(%this)
{
	TowerShopAlert.tangoSetPosition("370 35");
	TowerShopAlert.tangoMoveTo("370 -445", 500, elastic);

	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/select.wav"));
}