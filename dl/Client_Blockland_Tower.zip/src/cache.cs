// BLTC_SyncContentCache() Adds content inside the content/ to the cache.db.
// This way, clients won't be forced to download files from the server (which would be slow).
// Thanks Port for telling me about the addFileToCache function.

$BLTC::ContentDebug = false;

function BLTC_SyncContentCache()
{
	if($BLTC::SyncedCache)
		return;

	$BLTC::SyncedCache = true;

	%pattern = "Add-Ons/Client_Blockland_Tower/content/*.*";
	%file = findFirstFile(%pattern);

	while(isFile(%file))
	{
		addFileToCache(%file);

		if($BLTC::ContentDebug)
			echo(%file);

		%file = findNextFile(%pattern);
	}
}

schedule(200, 0, BLTC_SyncContentCache);