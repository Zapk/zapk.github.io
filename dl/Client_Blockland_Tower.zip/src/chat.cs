if(isPackage(BLTC_Package_Chat))
{
	deactivatePackage(BLTC_Package_Chat);
}

package BLTC_Package_Chat
{
	function NewChatSO::addLine(%this, %line)
   {
      if(stripos(%line, "<font:") < 0)
      {
         %line = "<font:Oswald:" @ newChatText.profile.fontSize @ ">" @ %line;

         BLTC_AudioChat(false);
         BLTC_AnimateChat();
      }

      Parent::addLine(%this, %line);
   }
};

BLTC_RegisterPackage(BLTC_Package_Chat);

function BLTC_AudioChat(%isSelf)
{
   %sound = (%isSelf ? "chat2" : "chat1");

   alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/content/sounds/" @ %sound @ ".wav"));
}

function BLTC_AnimateChat()
{
   if( getLineCount( newChatText.getText() ) >= $Pref::Chat::MaxDisplayLines )
	{
		newChatText.tangoSetPosition(2 SPC ( 20 + newChatText.profile.fontSize / 1.5 ));
      newChatText.tangoMoveTo(2 SPC 20, 100, expo);
	}
	else
	{
		newChatText.tangoSetPosition(2 SPC 17);
	}
}

function clientCmdBLT_ChatMessage(%placeName, %nameColor, %name, %msg)
{
	%s = "<font:Oswald:" @ newChatText.profile.fontSize @ ">";
	%s = %s @ "<color:A3A3A3>" @ %placeName @ " | ";
	%s = %s @ "<color:" @ %nameColor @ ">" @ %name;
	%s = %s @ "\c6: " @ %msg;

	NewChatSO.addLine(%s);

	%self = (%name $= $pref::Player::NetName);

	BLTC_AudioChat(%self);
	BLTC_AnimateChat();
}
