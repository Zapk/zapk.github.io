if(isPackage(BLTC_Package_Notifications))
{
	deactivatePackage(BLTC_Package_Notifications);
}

package BLTC_Package_Notifications
{
	function clientCmdBLT_Notification(%string, %icon)
	{
		BLTN_Create(%string, %icon);
	}

	function BLTN_Create(%string, %icon)
	{
		%string = StripMLControlChars(%string);
		%isIcon = (%icon !$= "");

		if(%string $= "")
		{
			return;
		}

		if( !isObject( BLTN_Manager ) )
		{
			new ScriptGroup( BLTN_Manager );
		}

		if(%isIcon)
		{
			%file = "Add-Ons/Client_Blockland_Tower/res/img/icons/" @ %icon @ ".png";

			if(!isFile(%file))
			{
				%isIcon = false;
			}
			else
			{
				%bmp = new GuiBitmapCtrl()
				{
					position = "6 10";
					extent = "16 16";
					maxLength = "256";
					bitmap = %file;
				};
			}
		}

		%text = new GuiTextCtrl()
		{
			profile = BLTN_TextProfile;
			position = %isIcon ? "26 -4" : "6 -4";
			minExtent = "1 2";
			maxLength = "256";
		};

		%text.setText(%string);

		%textsize = getWord( %text.getExtent(), 0 );

		%fullwidth = %textsize + 12 + (%isIcon ? 20 : 0);

		%swatch = new GuiSwatchCtrl()
		{
			minExtent = "1 2";
			color = "20 20 20 150";
			extent = %fullwidth SPC 38;
		};

		%prog = new GuiSwatchCtrl()
		{
			minExtent = "0 4";
			color = "255 255 255 255";
			extent = %fullwidth SPC 4;
			position = "0 34";
		};

		if(%isIcon)
		{
			%swatch.add(%bmp);
		}
		%swatch.add(%text);
		%swatch.add(%prog);
		%swatch.prog = %prog;

		PlayGUI.add(%swatch);

		%this = new ScriptObject()
		{
			class = BLTN_Notification;
			swatch = %swatch;
			startTime = getSimTime();
			existFor = strlen(%string) * 150;
		};

		BLTN_Manager.add(%this);

		%this.engines();
	}

	function BLTN_Notification::engines(%this)
	{
		%res = getRes();
		%res[x] = getWord( %res, 0 ) - 20;
		%res[y] = getWord( %res, 1 ) - 20;

		%this.y = %this.getGroup().getCount();

		%this.swatch.tangoSetPosition( %res[x] SPC %res[y] - (%this.y * 42) );

		%this.launch();
	}

	function BLTN_Notification::launch(%this)
	{
		%res = getRes();
		%res[x] = getWord( %res, 0 ) - 20;
		%res[y] = getWord( %res, 1 ) - 20;

		%width = getWord( %this.swatch.getExtent(), 0 );

		%this.swatch.tangoMoveTo( ( %res[x] - ( %width + 8 ) SPC %res[y] - (%this.y * 42) ), 750, elastic );

		%this.swatch.prog.tangoScaleTo( "0 4", %this.existFor - 1500, linear );

		%this.schedule(%this.existFor, landing);
	}

	function BLTN_Notification::landing(%this)
	{
		%res = getRes();
		%res[x] = getWord( %res, 0 ) - 20;
		%res[y] = getWord( %res, 1 ) - 20;

		%this.landing = true;
		%this.swatch.tangoMoveTo( %res[x] SPC %res[y] - (%this.y * 42), 750, expo );

		%this.schedule(750, landed);
	}

	function BLTN_Notification::landed(%this)
	{
		%this.swatch.delete();
		%this.delete();

		BLTN_Manager.trajectories();
	}

	function BLTN_Manager::trajectories(%this)
	{
		%res = getRes();
		%res[x] = getWord( %res, 0 ) - 20;
		%res[y] = getWord( %res, 1 ) - 20;

		if( isObject( %this.sorter ) )
		{
			%this.sorter.delete();
		}

		%this.sorter = new GuiTextListCtrl();

		%sorter = %this.sorter;

		for( %i = 0; %i < %this.getCount(); %i++ )
		{
			%obj = %this.getObject( %i );

			if(%obj.landing) continue;

			%sorter.addRow( %sorter.length, %obj TAB %obj.startTime );
			%sorter.length++;
		}

		%sorter.sortNumerical( 1, true );

		for( %row = %sorter.getRowText( %i = 0 ); %row !$= ""; %row = %sorter.getRowText( %i++ ) )
		{
			%note = getField( %row, 0 );
			%note.y = %i + 1;
			%width = getWord( %note.swatch.getExtent(), 0 );

			%note.swatch.tangoMoveTo( ( %res[x] - ( %width + 8 ) SPC %res[y] - (%note.y * 42) ), 750, expo );
		}
	}
};

BLTC_RegisterPackage(BLTC_Package_Notifications);
