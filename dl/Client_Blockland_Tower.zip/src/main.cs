// BLTC_SyncContentCache() Adds content inside the content/ to the cache.db.
// This way, clients won't be forced to download files from the server (which would be slow).
// Thanks Port for telling me about the addFileToCache function.
$BLTC::ContentDebug = false;
function BLTC_SyncContentCache()
{
	if($BLTC::SyncedCache)
		return;

	$BLTC::SyncedCache = true;

	%pattern = "Add-Ons/Client_Blockland_Tower/content/*.*";
	%file = findFirstFile(%pattern);

	while(isFile(%file))
	{
		addFileToCache(%file);

		if($BLTC::ContentDebug)
			echo(%file);

		%file = findNextFile(%pattern);
	}
}

schedule(200, 0, BLTC_SyncContentCache);

function clientCmdBLT_GoToServer(%ip)
{
	disconnect();
	schedule(2, 0, connectToServer, %ip);
}

function clientCmdBLT_SetLoadingScreen(%game)
{
	%file = "Add-Ons/Client_Blockland_Tower/res/img/loadscreens/" @ %game @ ".png";

	if(isFile(%file))
	{
		LOAD_MapPicture.setBitmap(%file);
	}
	else
	{
		LOAD_MapPicture.setBitmap("base/client/ui/loadingBG.png");
	}
}

//todo custom chat

function clientCmdBLT_ChatMessage(%placeName, %nameColor, %name, %msg)
{
	%size = newChatText.profile.fontSize;

	%s = "<font:Oswald:" @ %size @ ">";
	%s = %s @ "<color:A3A3A3>" @ %placeName @ " | ";
	%s = %s @ "<color:" @ %nameColor @ ">" @ %name;
	%s = %s @ "\c6: " @ %msg;

	NewChatSO.addLine(%s);

	%self = (%name $= $pref::Player::NetName);

	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/content/sounds/" @ (%self ? "chat1" : "chat2") @ ".wav"));

	if( getLineCount( newChatText.getText() ) > 2 )
	{
		newChatText.tangoSetPosition(2 SPC ( 20 + %size ));
	}
	else
	{
		newChatText.tangoSetPosition(2 SPC 17);
	}

	newChatText.tangoMoveTo(2 SPC 20, 100, expo);
}

function clientCmdBLT_Notification(%string)
{
	BLTN_Create(%string);
}

function BLTN_Create(%string)
{
	%string = StripMLControlChars(%string);

	if(%string $= "")
	{
		return;
	}

	if( !isObject( BLTN_Manager ) )
	{
		new ScriptGroup( BLTN_Manager );
	}

	%text = new GuiTextCtrl()
	{
		profile = BLTN_TextProfile;
		position = "6 -4";
		minExtent = "1 2";
		maxLength = "256";
	};
	%text.setText(%string);

	%textsize = getWord( %text.getExtent(), 0 );

	%fullwidth = %textsize + 12;

	%swatch = new GuiSwatchCtrl()
	{
		minExtent = "1 2";
		color = "80 80 80 150";
		extent = %fullwidth SPC 38;
	};

	%prog = new GuiSwatchCtrl()
	{
		minExtent = "0 4";
		color = "255 255 255 150";
		extent = %fullwidth SPC 4;
		position = "0 34";
	};

	%swatch.add(%text);
	%swatch.add(%prog);

	PlayGUI.add(%swatch);

	%this = new ScriptObject()
	{
		class = BLTN_Notification;
		swatch = %swatch;
		startTime = getSimTime();
		existFor = strlen(%string) * 150;
	};

	BLTN_Manager.add(%this);

	%this.engines();
}

function BLTN_Notification::engines(%this)
{
	%res = getRes();
	%res[x] = getWord( %res, 0 ) - 20;
	%res[y] = getWord( %res, 1 ) - 20;

	%this.y = %this.getGroup().getCount();

	%this.swatch.tangoSetPosition( %res[x] SPC %res[y] - (%this.y * 42) );

	%this.launch();
}

function BLTN_Notification::launch(%this)
{
	%res = getRes();
	%res[x] = getWord( %res, 0 ) - 20;
	%res[y] = getWord( %res, 1 ) - 20;

	%width = getWord( %this.swatch.getExtent(), 0 );

	%this.swatch.tangoMoveTo( ( %res[x] - ( %width + 8 ) SPC %res[y] - (%this.y * 42) ), 750, elastic );

	%this.swatch.getObject(1).tangoScaleTo( "0 4", %this.existFor - 750, linear );

	%this.schedule(%this.existFor, landing);
}

function BLTN_Notification::landing(%this)
{
	%res = getRes();
	%res[x] = getWord( %res, 0 ) - 20;
	%res[y] = getWord( %res, 1 ) - 20;

	%this.landing = true;
	%this.swatch.tangoMoveTo( %res[x] SPC %res[y] - (%this.y * 42), 750, expo );

	%this.schedule(750, landed);
}

function BLTN_Notification::landed(%this)
{
	%this.swatch.delete();
	%this.delete();

	BLTN_Manager.trajectories();
}

function BLTN_Manager::trajectories(%this)
{
	%res = getRes();
	%res[x] = getWord( %res, 0 ) - 20;
	%res[y] = getWord( %res, 1 ) - 20;

	if( isObject( %this.sorter ) )
	{
		%this.sorter.delete();
	}

	%this.sorter = new GuiTextListCtrl();

	%sorter = %this.sorter;

	for( %i = 0; %i < %this.getCount(); %i++ )
	{
		%obj = %this.getObject( %i );

		if(%obj.landing) continue;

		%sorter.addRow( %sorter.length, %obj TAB %obj.startTime );
		%sorter.length++;
	}

	%sorter.sortNumerical( 1, true );

	for( %row = %sorter.getRowText( %i = 0 ); %row !$= ""; %row = %sorter.getRowText( %i++ ) )
	{
		%note = getField( %row, 0 );
		%note.y = %i + 1;
		%width = getWord( %note.swatch.getExtent(), 0 );

		%note.swatch.tangoMoveTo( ( %res[x] - ( %width + 8 ) SPC %res[y] - (%note.y * 42) ), 750, expo );
	}
}

function BLTC_getPlasticVolume(%datablock)
{
	return %datablock.brickSizeX * %datablock.brickSizeY * %datablock.brickSizeZ;
}

//BLTC_BrickVolumeBitmap.setBitmap(BLTC_getBrickIconFromVolume(BLT_PlasticBuyField.getValue()));
function BLTC_getBrickIconFromVolume(%volume)
{
	%gr = DataBlockGroup;

	%cd = 100000;

	for(%i = 0; %i < %gr.getcount(); %i++)
	{
		%db = %gr.getObject(%i);
		if(%db.getClassName() !$= "fxDTSBrickData") continue;

		%v = BLTC_getPlasticVolume(%db);
		%d = VectorDist(%v,%volume);
		%img = %db.iconName;

		if(%d < %cd && %img !$= "")
		{
			echo(%d SPC %db.iconName);
			%cv = %v;
			%cd = %d;
			%ci = %img;
		}
	}

	%times = %volume / %cv;

	echo(%ci SPC "x" @ %times);

	return %ci;
}

function TowerHUD::positionHUD(%this)
{
	if( %this.getGroup().getName() !$= "PlayGui" )
	{
		return;
	}

	%y = getWord( getRes(), 1 ) - getWord( %this.getExtent(), 1 ) - 6;

	%this.tangoSetPosition( 0 SPC %y );
}

function clientCmdBLT_HUD_SetActive(%val)
{
	if( %val && TowerHUD.getGroup().getName() !$= "PlayGui" )
	{
		PlayGui.add( TowerHUD );
		TowerHUD.positionHUD();
	}

	else if( !%val && TowerHUD.getGroup().getName() !$= "GuiGroup" )
	{
		PlayGui.remove( TowerHUD );
		GuiGroup.add( TowerHUD );
	}
}

function clientCmdBLT_KeyText(%string, %msKeep)
{
	%msKeep = mClamp(%msKeep, 100, 10000);

	cancel($BLT::KeyDrop);
	$BLT::KeyDrop = schedule(%msKeep, 0, BLT_KeyDrop);

	TowerKeyGui.center();
	TowerKeyText.center();

	TowerKeyText.setText(%string);
	TowerKeyGui.setVisible(true);
}

function BLT_KeyDrop()
{
	cancel($BLT::KeyDrop);

	TowerKeyGui.setVisible(false);
}

function TowerHUD::updateText(%this)
{
	BLTC_HudText1.setText("<shadow:1:1><color:ffffff><font:Oswald:36>" @ numberFormat(%this.dVal["c"]) @ " <font:Oswald:18>BLC");
	BLTC_HudText2.setText("<shadow:1:1><color:ffffff><font:Oswald:18>" @ %this.dVal["l"]);
}

function clientCmdBLT_UpdateValue(%type, %val)
{
	if(%type $= "") return;

	TowerHUD.dVal[%type] = %val;
	TowerHUD.updateText();
}

if(isPackage(BLTC_Package))
{
	deactivatePackage(BLTC_Package);
}

package BLTC_Package
{
	function GameConnection::setConnectArgs( %a, %b, %c, %d, %e, %f, %g, %h, %i, %j )
	{
		%j = trim( %j @ "\tBLT " @ $BLTC::VersionInteger );

		Parent::setConnectArgs(%a, %b, %c, %d, %e, %f, %g, %h, %i, %j);
	}

	function disconnectedCleanup(%doReconnect)
	{
		%parent = Parent::disconnectedCleanup(%doReconnect);

		clientCmdBLT_HUD_SetActive(false);
		clientCmdBLT_SetLoadingScreen("");

		return %parent;
	}

	function resetCanvas()
	{
		%parent = Parent::resetCanvas();

		%this = nameToID( TowerHUD );

		if( isObject( %this ) )
		{
			%this.positionHUD();
		}

		return %parent;
	}

	function BLT_PlasticBuyField::setValue( %this, %string )
	{
		Parent::setValue( %this, %string );
		echo(%string);
	}
};

activatePackage(BLTC_Package);

function TowerShop::clean(%this)
{
	TowerShopWindow.setText("Shop");
	TowerShopList.clear();
	TowerShopText.setText("<font:Oswald:32>No Item Selected");
	TowerShopBuyButton.setVisible(false);
	TowerShopImage.setBitmap("Add-Ons/Client_Blockland_Tower/res/img/items/unknown.png");
	TowerShopAlert.tangoSetPosition("370 490");
}

function TowerShop::open(%this, %title)
{
	%this.clean();
	TowerShopWindow.setText(%title);
	Canvas.pushDialog(%this);

	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/hover.wav"));
}

function clientCmdBLT_Shop_Open(%title)
{
	TowerShop.open(%title);
}

function TowerShop::close(%this)
{
	Canvas.popDialog(%this);
	%this.clean();
	commandToServer('Shop_Cancel');

	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/hover.wav"));
}

function TowerShop::slideAnimation(%this)
{
	%e = quart;
	%t = 250;

	TowerShopSide1.extent = "260 435";
	TowerShopSide1.tangoScaleTo("260 255", %t, %e);

	TowerShopSide1.getObject(0).extent = "244 419";
	TowerShopSide1.getObject(0).tangoScaleTo("244 239", %t, %e);

	TowerShopSide2.extent = "260 0";
	TowerShopSide2.tangoScaleTo("260 170", %t, %e);

	TowerShopSide2.tangoSetPosition("370 470");
	TowerShopSide2.tangoMoveTo("370 300", %t, %e);
}

function TowerShop::addShopItem(%this, %cost, %name, %item, %desc)
{
	%list = TowerShopList;

	%row = numberFormat(%cost) SPC "BLC";
	%row = %row @ "\t" @ %name;
	%row = %row @ "\t" @ %item;
	%row = %row @ "\t" @ %desc;

	%list.addRow(%list.rowCount(), %row);
}

function clientCmdBLT_Shop_AddItem(%cost, %name, %item, %desc)
{
	TowerShop.addShopItem(%cost, %name, %item, %desc);
}

function TowerShop::clickList(%this)
{
	%idx = TowerShopList.getSelectedID();

	%row = TowerShopList.getRowText(%idx);

	%cost = getField(%row, 0);
	%name = getField(%row, 1);
	%item = getField(%row, 2);
	%desc = getField(%row, 3);

	%btmp = "Add-Ons/Client_Blockland_Tower/res/img/items/" @ %item @ ".png";

	TowerShopText.setText("<font:Oswald:32>" @ %name @ " <font:Oswald:18>" @ %cost @ "<br><font:Oswald ExtraLight:22>" @ %desc);

	if(isFile(%btmp))
		TowerShopImage.setBitmap(%btmp);
	else
		TowerShopImage.setBitmap("Add-Ons/Client_Blockland_Tower/res/img/items/unknown.png");

	%this.selectedItem = %item;

	TowerShopBuyButton.setVisible(true);

	%this.slideAnimation();

	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/select.wav"));
}

function TowerShop::clickBuy(%this)
{
	commandToServer('Shop_Buy', %this.selectedItem);

	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/select.wav"));
}

function TowerShop::alert(%this, %text)
{
	TowerShopAlertText.setText("<font:Oswald ExtraLight:24>" @ %text);
	TowerShopAlert.setVisible(true);

	TowerShopAlert.tangoSetPosition("370 490");
	TowerShopAlert.tangoMoveTo("370 35", 500, elastic);

	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/blip1.wav"));
}

function clientCmdBLT_Shop_Alert(%text)
{
	TowerShop.alert(%text);
}

function TowerShop::clickDismiss(%this)
{
	TowerShopAlert.tangoSetPosition("370 35");
	TowerShopAlert.tangoMoveTo("370 -445", 500, elastic);

	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/select.wav"));
}
