$BLTC::src = "Add-Ons/Client_Blockland_Tower/src/";
$BLTC::lib = "Add-Ons/Client_Blockland_Tower/lib/";
$BLTC::res = "Add-Ons/Client_Blockland_Tower/res/";

function BLTC_Reload()
{
	exec($BLTC::src @ "kernel.cs");
}

////////////////////////////////////////////////////////////////

exec($BLTC::lib @ "tango.cs");
exec($BLTC::lib @ "rtbFunctions.cs");
exec($BLTC::lib @ "jettison.cs");

////////////////////////////////////////////////////////////////

$BLTC::PackageCount = 0;

function BLTC_RegisterPackage(%name)
{
	$BLTC::Package[$BLTC::PackageCount] = %name;
	$BLTC::PackageCount++;

	if($OnTowerLobby)
	{
		activatePackage(%name);
	}
}

function BLTC_SetPackagesActive(%isActive)
{
	for(%i = 0; %i < $BLTC::PackageCount; %i++)
	{
		%package = $BLTC::Package[%i];

		if(%isActive)
		{
			activatePackage(%package);
		}
		else
		{
			deactivatePackage(%package);
		}
	}
}

////////////////////////////////////////////////////////////////

exec($BLTC::src @ "profiles.cs");

if(!isObject(TowerKeyGui))
	exec($BLTC::res @ "gui/TowerKeyGui.gui");
if(!isObject(TowerHUD))
	exec($BLTC::res @ "gui/TowerHUD.gui");
if(!isObject(TowerInventory))
	exec($BLTC::res @ "gui/TowerInventory.gui");
if(!isObject(TowerLoading))
	exec($BLTC::res @ "gui/TowerLoading.gui");
if(!isObject(TowerShop))
	exec($BLTC::res @ "gui/TowerShop.gui");
if(!isObject(TowerSuites))
	exec($BLTC::res @ "gui/TowerSuites.gui");
if(!isObject(TowerPiano))
	exec($BLTC::res @ "gui/TowerPiano.gui");
if(!isObject(TowerPlastic))
	exec($BLTC::res @ "gui/TowerPlastic.gui");

////////////////////////////////////////////////////////////////

exec($BLTC::src @ "cache.cs");
exec($BLTC::src @ "loading.cs");
exec($BLTC::src @ "notifications.cs");
exec($BLTC::src @ "hud.cs");
exec($BLTC::src @ "chat.cs");
exec($BLTC::src @ "key.cs");
exec($BLTC::src @ "shop.cs");
exec($BLTC::src @ "suites.cs");
exec($BLTC::src @ "drunk.cs");
exec($BLTC::src @ "inventory.cs");
exec($BLTC::src @ "soundscapes.cs");
exec($BLTC::src @ "piano.cs");

////////////////////////////////////////////////////////////////

if(isPackage(BLTC_Package_Kernel))
{
	deactivatePackage(BLTC_Package_Kernel);
}

package BLTC_Package_Kernel
{
	function GameConnection::setConnectArgs( %a, %b, %c, %d, %e, %f, %g, %h, %i, %j )
	{
		%j = trim( %j @ "\tBLT " @ $BLTC::VersionInteger );

		Parent::setConnectArgs(%a, %b, %c, %d, %e, %f, %g, %h, %i, %j);
	}

	function disconnectedCleanup(%doReconnect)
	{
		%parent = Parent::disconnectedCleanup(%doReconnect);

		BLTC_SetPackagesActive(false);

		$OnTowerLobby = false;

		return %parent;
	}

	function BLT_PlasticBuyField::setValue( %this, %string )
	{
		Parent::setValue( %this, %string );
		echo(%string);
	}
};

activatePackage(BLTC_Package_Kernel);

function BLTC_LoadVersion()
{
	%file = "Add-Ons/Client_Blockland_Tower/version.json";

	if(jettisonReadFile(%file))
	{
		error("Failed to parse JSON: " @ $JSON::Error);
		return;
	}

	%version = $JSON::Value.value["version"];

	$BLTC::VersionString = %version;
	$BLTC::VersionInteger = mFloor( strreplace( %version, ".", "" ) );

	if($JSON::Type $= "object")
	{
		$JSON::Value.delete();
	}
}

if($BLTC::VersionString $= "")
{
	schedule(0, 0, BLTC_LoadVersion);
}

function clientCmdBLT_GoToServer(%ip)
{
	disconnect();
	schedule(500, 0, connectToServer, %ip);
}

function clientCmdBLT_ScreenFade(%doFade, %timeMS)
{
	ServerConnection.setBlackOut(%doFade, %timeMS);
}

function BLTC_getPlasticVolume(%datablock)
{
	return %datablock.brickSizeX * %datablock.brickSizeY * %datablock.brickSizeZ;
}

//BLTC_BrickVolumeBitmap.setBitmap(BLTC_getBrickIconFromVolume(BLT_PlasticBuyField.getValue()));
function BLTC_getBrickIconFromVolume(%volume)
{
	%gr = DataBlockGroup;

	%cd = 100000;

	%count = %gr.getCount();
	for(%i = 0; %i < %count; %i++)
	{
		%db = %gr.getObject(%i);
		if(%db.getClassName() !$= "fxDTSBrickData") continue;

		%v = BLTC_getPlasticVolume(%db);
		%d = VectorDist(%v,%volume);
		%img = %db.iconName;

		if(%d < %cd && %img !$= "")
		{
			echo(%d SPC %db.iconName);
			%cv = %v;
			%cd = %d;
			%ci = %img;
		}
	}

	%times = %volume / %cv;

	echo(%ci SPC "x" @ %times);

	return %ci;
}

function clientCmdBLT_PlayUISound(%select)
{
	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/" @ (%select ? "select" : "hover") @ ".wav"));
}
