if(!isObject(BLT_PianoWhiteKeyProfile))
{
   new GuiControlProfile(BLT_PianoWhiteKeyProfile)
   {
      fontType = "Impact";
      fontSize = "18";
      fontColor = "50 50 50 255";
      justify = "center";
   };
}

if(!isObject(BLT_PianoBlackKeyProfile))
{
   new GuiControlProfile(BLT_PianoBlackKeyProfile : BLT_PianoWhiteKeyProfile)
   {
      fontColor = "200 200 200 255";
   };
}

if(!isObject(TowerCenterText))
{
   new GuiControlProfile(TowerCenterText : BLT_PianoWhiteKeyProfile)
   {
      fontColor = "240 240 240 255";
      fontSize = "42";
   };
}

if(!isObject(BLTN_ProgressProfile))
{
	new GuiControlProfile(BLTN_ProgressProfile : GuiProgressProfile)
	{
		fillColor = "0 150 80 255";
		border = "0";
	};
}

if(!isObject(BLTN_TextProfile))
{
	new GuiControlProfile(BLTN_TextProfile : GuiTextProfile)
	{
		fontColors[0] = "255 255 255 255";
		fontType = "Oswald Light";
		fontSize = "32";
	};
}

if(!isObject(BLT_InventoryNumberProfile))
{
	new GuiControlProfile(BLT_InventoryNumberProfile : GuiTextProfile)
	{
		fontColors[0] = "64 64 64 255";
		fontType = "Oswald Light";
		fontSize = "32";
	};
}

if(!isObject(BLT_WindowProfile))
{
	new GuiControlProfile(BLT_WindowProfile : GuiWindowProfile)
	{
		fontColor = "255 255 255 217";
		fontType = "Arial";
		fontSize = "12";
		textOffset = "7 7";
		fillColor = "108 111 114 255";
		bitmap = $BLTC::res @ "img/window.png";
	};
}

if(!isObject(BLT_ScrollProfile))
{
	new GuiControlProfile(BLT_ScrollProfile : GuiScrollProfile)
	{
		border = false;
		opaque = false;
		fillColor = "0 0 0 0";
		bitmap = $BLTC::res @ "img/scroll.png";
	};
}

if(!isObject(BLT_PanelProfile))
{
	new GuiControlProfile(BLT_PanelProfile : GuiBitmapBorderProfile)
	{
		opaque = false;
		fillColor = "234 234 234 255";
		bitmap = $BLTC::res @ "img/panel.png";
	};
}

if(!isObject(BLT_PanelDProfile))
{
	new GuiControlProfile(BLT_PanelDProfile : BLT_PanelProfile)
	{
		fillColor = "195 195 195 255";
		bitmap = $BLTC::res @ "img/dpanel.png";
	};
}

if(!isObject(BLT_TooltipProfile))
{
	new GuiControlProfile(BLT_TooltipProfile : BLT_PanelProfile)
	{
		fillColor = "249 238 181 255";
		bitmap = $BLTC::res @ "img/tooltip.png";
	};
}

if(!isObject(BLT_TextEnterBGProfile))
{
	new GuiControlProfile(BLT_TextEnterBGProfile : BLT_PanelProfile)
	{
		opaque = false;
		fillColor = "255 255 255 255";
		bitmap = $BLTC::res @ "img/textentry.png";
	};
}

if(!isObject(BLT_TextEnterBGSelProfile))
{
	new GuiControlProfile(BLT_TextEnterBGSelProfile : BLT_TextEnterBGProfile)
	{
		fillColor = "254 253 214 255";
		bitmap = $BLTC::res @ "img/textentrysel.png";
	};
}

if(!isObject(BLT_TextProfile))
{
	new GuiControlProfile(BLT_TextProfile : GuiDefaultProfile)
	{
		fontColor = "255 255 255 217";
		fontType = "Arial";
		fontSize = "12";
	};
}

if(!isObject(BLT_ButtonTextProfile))
{
	new GuiControlProfile(BLT_ButtonTextProfile : BLT_TextProfile)
	{
		justify = "center";
		fontColor = "10 10 10 255";
		fontType = "Arial";
		fontSize = "14";
	};
}

if(!isObject(BLT_TextEnterProfile))
{
	new GuiControlProfile(BLT_TextEnterProfile : GuiTextEditProfile)
	{
		autoSizeHeight = false;
		border = false;
		opaque = false;
		fillColor = "0 0 0 0";
		fontColor = "67 67 67 255";
		fontType = "Arial";
		fontSize = "12";
	};
}
