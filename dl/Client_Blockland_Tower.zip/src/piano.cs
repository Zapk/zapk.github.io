function BLT_PianoKey(%bind, %sound, %img, %label, %x)
{
   $BLT::PianoBind[ $BLT::PianoKeys ] = %bind;
   $BLT::PianoLabel[ $BLT::PianoKeys ] = %label;
   $BLT::PianoSound[ $BLT::PianoKeys ] = %sound;
   $BLT::PianoImage[ $BLT::PianoKeys ] = %img;
   $BLT::PianoPos[ $BLT::PianoKeys ] = %x;

   $BLT::PianoKeys++;
}

function BLT_PianoChangeMode()
{
   $BLT::PianoMode = !$BLT::PianoMode;
   BLT_PianoGuiBuild();
}

function BLT_PianoGuiBuild()
{
   $BLT::PianoMode = !!$BLT::PianoMode;
   $BLT::PianoKeys = 0;

   if(!$BLT::PianoMode)
   {
      BLT_PianoKey("a", "a15", "left", "A", 19);
      BLT_PianoKey("s", "a16", "middle", "S", 44);
      BLT_PianoKey("d", "a17", "right", "D", 69);
      BLT_PianoKey("f", "a18", "left", "F", 94);
      BLT_PianoKey("g", "a19", "leftmid", "G", 119);
      BLT_PianoKey("h", "a20", "rightmid", "H", 144);
      BLT_PianoKey("j", "a21", "right", "J", 169);
      BLT_PianoKey("k", "a22", "left", "K", 194);
      BLT_PianoKey("l", "a23", "middle", "L", 219);
      BLT_PianoKey(";", "a24", "right", ";", 244);
      BLT_PianoKey("'", "a25", "full", "'", 269);

      BLT_PianoKey("w", "b11", "top", "W", 33);
      BLT_PianoKey("e", "b12", "top", "E", 64);
      BLT_PianoKey("t", "b13", "top", "T", 108);
      BLT_PianoKey("y", "b14", "top", "Y", 136);
      BLT_PianoKey("u", "b15", "top", "U", 164);
      BLT_PianoKey("o", "b16", "top", "O", 208);
      BLT_PianoKey("p", "b17", "top", "P", 239);

      %pianoExtent = "313 197";
      %pianoBitmap = "Add-Ons/Client_Blockland_Tower/res/img/piano";
   }
   else
   {
      BLT_PianoKey("1", "a1", "left", "1", 19);
      BLT_PianoKey("shift 1", "b1", "top", "!", 33);
      BLT_PianoKey("2", "a2", "middle", "2", 44);
      BLT_PianoKey("shift 2", "b2", "top", "@", 64);
      BLT_PianoKey("3", "a3", "right", "3", 69);
      BLT_PianoKey("4", "a4", "left", "4", 94);
      BLT_PianoKey("shift 4", "b3", "top", "$", 108);
      BLT_PianoKey("5", "a5", "leftmid", "5", 119);
      BLT_PianoKey("shift 5", "b4", "top", "%", 136);
      BLT_PianoKey("6", "a6", "rightmid", "6", 144);
      BLT_PianoKey("shift 6", "b5", "top", "^", 164);
      BLT_PianoKey("7", "a7", "right", "7", 169);
      BLT_PianoKey("8", "a8", "left", "8", 194);
      BLT_PianoKey("shift 8", "b6", "top", "*", 208);
      BLT_PianoKey("9", "a9", "middle", "9", 219);
      BLT_PianoKey("shift 9", "b7", "top", "(", 239);
      BLT_PianoKey("0", "a10", "right", "0", 244);
      BLT_PianoKey("Q", "a11", "left", "q", 269);
      BLT_PianoKey("shift q", "b8", "top", "Q", 283);
      BLT_PianoKey("W", "a12", "leftmid", "w", 294);
      BLT_PianoKey("shift w", "b9", "top", "W", 310);
      BLT_PianoKey("E", "a13", "rightmid", "e", 319);
      BLT_PianoKey("shift e", "b10", "top", "E", 339);
      BLT_PianoKey("R", "a14", "right", "r", 344);
      BLT_PianoKey("T", "a15", "left", "t", 369);
      BLT_PianoKey("shift t", "b11", "top", "T", 383);
      BLT_PianoKey("Y", "a16", "middle", "y", 394);
      BLT_PianoKey("shift y", "b12", "top", "Y", 414);
      BLT_PianoKey("U", "a17", "right", "u", 419);
      BLT_PianoKey("I", "a18", "left", "i", 444);
      BLT_PianoKey("shift i", "b13", "top", "I", 458);
      BLT_PianoKey("O", "a19", "leftmid", "o", 469);
      BLT_PianoKey("shift o", "b14", "top", "O", 486);
      BLT_PianoKey("P", "a20", "rightmid", "p", 494);
      BLT_PianoKey("shift p", "b15", "top", "P", 514);
      BLT_PianoKey("A", "a21", "right", "a", 519);
      BLT_PianoKey("S", "a22", "left", "s", 544);
      BLT_PianoKey("shift s", "b16", "top", "S", 558);
      BLT_PianoKey("D", "a23", "middle", "d", 569);
      BLT_PianoKey("shift d", "b17", "top", "D", 590);
      BLT_PianoKey("F", "a24", "right", "f", 594);
      BLT_PianoKey("G", "a25", "left", "g", 619);
      BLT_PianoKey("shift g", "b18", "top", "G", 633);
      BLT_PianoKey("H", "a26", "leftmid", "h", 644);
      BLT_PianoKey("shift h", "b19", "top", "H", 661);
      BLT_PianoKey("J", "a27", "rightmid", "j", 669);
      BLT_PianoKey("shift j", "b20", "top", "J", 690);
      BLT_PianoKey("K", "a28", "right", "k", 694);
      BLT_PianoKey("L", "a29", "left", "l", 719);
      BLT_PianoKey("shift l", "b21", "top", "L", 734);
      BLT_PianoKey("Z", "a30", "middle", "z", 744);
      BLT_PianoKey("shift z", "b22", "top", "Z", 765);
      BLT_PianoKey("X", "a31", "right", "x", 769);
      BLT_PianoKey("C", "a32", "left", "c", 794);
      BLT_PianoKey("shift c", "b23", "top", "C", 809);
      BLT_PianoKey("V", "a33", "leftmid", "v", 819);
      BLT_PianoKey("shift v", "b24", "top", "V", 837);
      BLT_PianoKey("B", "a34", "rightmid", "b", 844);
      BLT_PianoKey("shift b", "b25", "top", "B", 865);
      BLT_PianoKey("N", "a35", "right", "n", 869);
      BLT_PianoKey("M", "a36", "full", "m", 894);

      %pianoExtent = "937 197";
      %pianoBitmap = "Add-Ons/Client_Blockland_Tower/res/img/piano_large";
   }

   BLT_PianoBitmap.getGroup().extent = %pianoExtent;
   BLT_PianoBitmap.extent = %pianoExtent;
   BLT_PianoBitmap.setBitmap(%pianoBitmap);

   BLT_PianoBitmap.getGroup().center();

   BLT_PianoText1.centerX();
   BLT_PianoText2.centerX();

   BLT_PianoText2.setText("CONTROL FOR" SPC ($BLT::PianoMode ? "BASIC" : "ADVANCED") SPC "MODE");

   if(isObject(BLT_PianoMap))
   {
      BLT_PianoMap.delete();
   }

   new ActionMap(BLT_PianoMap);

   %bp = BLT_PianoBitmap.getID();

   if(!isObject(%bp))
   {
      return error("No BLT_PianoBitmap!");
   }

   %bp.deleteAll();

   BLT_PianoMap.bind(keyboard, getField(moveMap.getBinding("Jump"), 1), Jump);
   BLT_PianoMap.bindCmd(keyboard, "lcontrol", "", "BLT_PianoChangeMode();");
   BLT_PianoMap.bindCmd(keyboard, "rcontrol", "", "BLT_PianoChangeMode();");

   for(%i = 0; %i < $BLT::PianoKeys; %i++)
   {
      %img = $BLT::PianoImage[%i];
      %extent = (%img $= "top" ? "15 70" : "24 125");

      %textent = (%img $= "top" ? "15 28" : "24 55");
      %textprofile = (%img $= "top" ? BLT_PianoBlackKeyProfile : BLT_PianoWhiteKeyProfile);
      %texty = (%img $= "top" ? 55 : 110);

      BLT_PianoMap.bindCmd(keyboard, $BLT::PianoBind[%i], "BLT_PianoDown(" @ %i @ ");", "BLT_PianoUp(" @ %i @ ");");

      %btn = new GuiBitmapCtrl("BLT_PianoBitmap" @ %i)
      {
         position = $BLT::PianoPos[%i] SPC 30;
         extent = %extent;
         bitmap = "Add-Ons/Client_Blockland_Tower/res/img/piano_note_" @ %img @ "_d";
         visible = false;
      };

      %text = new GuiTextCtrl()
      {
         position = $BLT::PianoPos[%i] SPC %texty;
         text = $BLT::PianoLabel[%i];
         extent = %textent;
         profile = %textprofile;
      };

      %bp.add(%btn);
      %bp.add(%text);
   }

   BLT_PianoMap.push();
}

function BLT_PianoDown(%i)
{
   nameToID("BLT_PianoBitmap" @ %i).setVisible(true);

   commandToServer('BLT_Piano_Press', $BLT::PianoSound[ %i ]);
}

function BLT_PianoUp(%i)
{
   nameToID("BLT_PianoBitmap" @ %i).setVisible(false);
}

function clientCmdBLT_Piano_SetActive(%val)
{
	if(%val)
	{
		BLT_PianoGuiBuild();
		Canvas.pushDialog(TowerPiano);

		moveMap.pop();
	}

	else
	{
		moveMap.push();

      if(isObject(BLT_PianoMap))
		    BLT_PianoMap.pop();

		Canvas.popDialog(TowerPiano);
	}
}
