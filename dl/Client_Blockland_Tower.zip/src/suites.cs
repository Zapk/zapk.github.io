if(isPackage(BLTC_Package_Suites))
{
	deactivatePackage(BLTC_Package_Suites);
}

package BLTC_Package_Suites
{
	function GuiMouseEventCtrl::onMouseEnter( %this )
	{
		Parent::onMouseEnter(%this);

		if(%this.isSuiteButton)
		{
			alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/hover.wav"));
			%this.bitmap.setBitmap("Add-Ons/Client_Blockland_Tower/res/img/large_h");
		}
	}

	function GuiMouseEventCtrl::onMouseLeave( %this )
	{
		Parent::onMouseLeave(%this);

		if(%this.isSuiteButton)
		{
			%this.bitmap.setBitmap("Add-Ons/Client_Blockland_Tower/res/img/large_n");
		}
	}

	function GuiMouseEventCtrl::onMouseDown( %this )
	{
		Parent::onMouseDown(%this);

		if(%this.isSuiteButton)
		{
			alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/select.wav"));
			%this.bitmap.setBitmap("Add-Ons/Client_Blockland_Tower/res/img/large_d");
		}
	}

	function GuiMouseEventCtrl::onMouseUp( %this )
	{
		Parent::onMouseUp(%this);

		if(%this.isSuiteButton)
		{
			%this.bitmap.setBitmap("Add-Ons/Client_Blockland_Tower/res/img/large_h");

			if(%this.command !$= "")
				eval(%this.command);
		}
	}
};

BLTC_RegisterPackage(BLTC_Package_Suites);

function TowerSuites::open(%this, %available, %max, %checkedIn)
{
	Canvas.pushDialog(%this);

	TowerSuitesInfoText.setText("<just:center><font:Oswald Light:50>" @ %available @ "/" @ %max @ " suites available.");

	TowerSuitesCover.setVisible(%available < 1 && !%checkedIn);

	TowerSuiteBtnText.setText("<font:Oswald:40><color:ffffff>" @ (%checkedIn ? "Check Out" : "Check In"));
}

function clientCmdBLT_Suites_Open(%available, %max, %checkedIn)
{
	TowerSuites.open(%available, %max, %checkedIn);
}

function TowerSuites::clickClose(%this)
{
	Canvas.popDialog(%this);
	commandToServer('Suites_Cancel');
}

function TowerSuites::clickCheck(%this)
{
	Canvas.popDialog(%this);
	commandToServer('Suites_Check');
}
