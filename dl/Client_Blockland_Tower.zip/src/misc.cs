if(isPackage(BLTC_Package_Misc))
{
	deactivatePackage(BLTC_Package_Misc);
}

package BLTC_Package_Misc
{
   function clientCmdBLT_GoToServer(%ip)
   {
   	disconnect();
   	schedule(500, 0, connectToServer, %ip);
   }

   function clientCmdBLT_ScreenFade(%doFade, %timeMS)
   {
   	ServerConnection.setBlackOut(%doFade, %timeMS);
   }

   function BLTC_getPlasticVolume(%datablock)
   {
   	return %datablock.brickSizeX * %datablock.brickSizeY * %datablock.brickSizeZ;
   }

   //BLTC_BrickVolumeBitmap.setBitmap(BLTC_getBrickIconFromVolume(BLT_PlasticBuyField.getValue()));
   function BLTC_getBrickIconFromVolume(%volume)
   {
   	%gr = DataBlockGroup;

   	%cd = 100000;

   	%count = %gr.getCount();
   	for(%i = 0; %i < %count; %i++)
   	{
   		%db = %gr.getObject(%i);
   		if(%db.getClassName() !$= "fxDTSBrickData") continue;

   		%v = BLTC_getPlasticVolume(%db);
   		%d = VectorDist(%v,%volume);
   		%img = %db.iconName;

   		if(%d < %cd && %img !$= "")
   		{
   			echo(%d SPC %db.iconName);
   			%cv = %v;
   			%cd = %d;
   			%ci = %img;
   		}
   	}

   	%times = %volume / %cv;

   	echo(%ci SPC "x" @ %times);

   	return %ci;
   }

   function clientCmdBLT_PlayUISound(%select)
   {
   	alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/res/sfx/" @ (%select ? "select" : "hover") @ ".wav"));
   }

};

BLTC_RegisterPackage(BLTC_Package_Misc);
