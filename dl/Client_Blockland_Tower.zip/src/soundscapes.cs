if(isPackage(BLTC_Package_Soundscapes))
{
	deactivatePackage(BLTC_Package_Soundscapes);
}

package BLTC_Package_Soundscapes
{
   function TowerScape::setSoundscape(%this, %name)
   {
      if(%this.currentScape $= %name)
      {
         return;
      }

      %this.currentScape = %name;

      %this.fadeBackIn = false;
      %this.newSoundscape = "";

      if(%name $= "")
      {
         %this.fadeOut();
         return;
      }

      %this.fadeBackIn = true;
      %this.newSoundscape = %name;

      %this.fadeOut();
   }

   function TowerScape::_stopScape(%this)
   {
      if(alxIsPlaying(%this.source))
         alxStop(%this.source);
   }

   function TowerScape::_setSoundscape(%this, %name)
   {
      %this._stopScape();

      %file = "Add-Ons/Client_Blockland_Tower/res/soundscapes/" @ %name @ ".wav";

      if(!isFile(%file))
      {
         return;
      }

      %this.source = alxPlay(alxCreateSource(AudioTowerScape, %file));
      %this.currentScape = %name;
   }

   function TowerScape::fadeOut(%this, %volume)
   {
      cancel(%this.tick);

      if(%volume $= "")
         %volume = 0.9;

      if(%volume < 0)
      {
         alxSetChannelVolume(16, 0.1);

         if(%this.newSoundscape !$= "")
         {
            %this._setSoundscape(%this.newSoundscape);
         }
         else
         {
            %this._stopScape();
         }

         if(%this.fadeBackIn)
         {
            %this.fadeIn();
         }

         return;
      }

      alxSetChannelVolume(16, %volume);

      %this.tick = %this.schedule(1, fadeOut, %volume - 0.02);
   }

   function TowerScape::fadeIn(%this, %volume)
   {
      cancel(%this.tick);

      if(%volume $= "")
         %volume = 0.0;

      if(%volume > 0.9)
      {
         alxSetChannelVolume(16, 0.9);
         return;
      }

      alxSetChannelVolume(16, %volume);

      %this.tick = %this.schedule(1, fadeIn, %volume + 0.02);
   }

   function clientCmdBLT_SetSoundscape(%name)
   {
      if(!isObject(AudioTowerScape))
      {
         new AudioDescription(AudioTowerScape : AudioGui)
         {
            type = 16;
            isLooping = true;
            volume = 2;
         };
      }

      if(!isObject(TowerScape))
      {
         new ScriptObject(TowerScape);
      }

      TowerScape.setSoundscape(%name);
   }
};

BLTC_RegisterPackage(BLTC_Package_Soundscapes);
