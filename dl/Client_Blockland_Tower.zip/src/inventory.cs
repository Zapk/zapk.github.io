if(isPackage(BLTC_Package_Inventory))
{
	deactivatePackage(BLTC_Package_Inventory);
}

package BLTC_Package_Inventory
{
	function GuiMouseEventCtrl::onMouseEnter( %this )
	{
		Parent::onMouseEnter(%this);

		if((%n = %this.towerInventoryNumber) !$= "")
		{
			if(isObject(%o = "TI_Panel_" @ %n)) %o.setBitmap("Add-Ons/Client_Blockland_Tower/res/img/panel_h");
			BLTC_AnimateInventory(2);
			BLTC_InventoryTooltip($BLTC::Inventory::ItemName[%n]);
		}
	}

	function GuiMouseEventCtrl::onMouseLeave( %this )
	{
		Parent::onMouseLeave(%this);

		if((%n = %this.towerInventoryNumber) !$= "")
		{
			if(isObject(%o = "TI_Panel_" @ %n)) %o.setBitmap(%n == $BLTC::UsingSlot ? "Add-Ons/Client_Blockland_Tower/res/img/panel_i" : "Add-Ons/Client_Blockland_Tower/res/img/panel_n");
			BLTC_InventoryTooltip();
		}
	}

	function GuiMouseEventCtrl::onMouseDown( %this )
	{
		Parent::onMouseDown(%this);

		if((%n = %this.towerInventoryNumber) !$= "")
		{
			if(isObject(%o = "TI_Panel_" @ %n)) %o.setBitmap("Add-Ons/Client_Blockland_Tower/res/img/panel_d");
		}
	}

	function GuiMouseEventCtrl::onMouseUp( %this )
	{
		Parent::onMouseUp(%this);

		if((%n = %this.towerInventoryNumber) !$= "")
		{
			if(isObject(%o = "TI_Panel_" @ %n)) %o.setBitmap("Add-Ons/Client_Blockland_Tower/res/img/panel_h");
		}
	}

	function GuiPopUpMenuCtrl::onSelect( %this, %id )
	{
		Parent::onSelect(%this, %id);

		if(%this.getName() $= "BLTC_InventoryContextMenu")
		{
			echo("Context menu: selected (" @ %id @ ")");

			%slot = %this.inventorySlot;

			switch(%id)
			{
				case 0:
					MessageBoxYesNo("Inventory", "Do you want to sell your " @ $BLTC::Inventory::ItemName[%slot] @ " for half its retail value?", "commandToServer('BLT_InventorySell', " @ %slot @ ");");
			}

			%this.delete();
		}
	}

	function GuiMouseEventCtrl::onRightMouseDown( %this )
	{
		Parent::onRightMouseDown(%this);

		if((%n = %this.towerInventoryNumber) !$= "")
		{
			if(isObject(%o = "TI_Panel_" @ %n)) %o.setBitmap("Add-Ons/Client_Blockland_Tower/res/img/panel_d");

			if(isObject(BLTC_InventoryContextMenu))
			{
				BLTC_InventoryContextMenu.delete();
			}

			if($BLTC::Inventory::ItemID[%n] !$= "")
			{
				new GuiPopUpMenuCtrl(BLTC_InventoryContextMenu)
				{
					minExtent = "8 0";
					extent = "128 0";
					position = Canvas.getCursorPos();
					text = "{Context_Menu}";
					inventorySlot = %n;
				};

				BLTC_InventoryContextMenu.add("Sell", 0);

				TowerInventory.add(BLTC_InventoryContextMenu);

				BLTC_InventoryContextMenu.forceOnAction();
			}
		}
	}

	function GuiMouseEventCtrl::onRightMouseUp( %this )
	{
		Parent::onRightMouseUp(%this);

		if((%n = %this.towerInventoryNumber) !$= "")
		{
			if(isObject(%o = "TI_Panel_" @ %n)) %o.setBitmap("Add-Ons/Client_Blockland_Tower/res/img/panel_h");
		}
	}

	function useTools(%v)
	{
		if(!$TowerBuildingMode)
		{
			if(%v)
			{
				BLTC_BuildInventoryGui();
				Canvas.cursorOn();
			}
			else
			{
				Canvas.cursorOff();
			}

			BLTC_AnimateInventory(%v);
		}
		else
		{
			Parent::useTools(%v);
		}
	}

	function useSprayCan(%v)
	{
		if(!$TowerBuildingMode)
		{
			commandToServer('BLT_OrbitMe', %v);
		}
		else
		{
			Parent::useSprayCan(%v);
		}
	}

	function useBricks(%v) { if(!BLTC_PressNumber(1, %v)) { return Parent::useBricks(%v); } }
	function useFirstSlot(%v) { if(!BLTC_PressNumber(1, %v)) { return Parent::useFirstSlot(%v); } }
	function useSecondSlot(%v) { if(!BLTC_PressNumber(2, %v)) { return Parent::useSecondSlot(%v); } }
	function useThirdSlot(%v) { if(!BLTC_PressNumber(3, %v)) { return Parent::useThirdSlot(%v); } }
	function useFourthSlot(%v) { if(!BLTC_PressNumber(4, %v)) { return Parent::useFourthSlot(%v); } }
	function useFifthSlot(%v) { if(!BLTC_PressNumber(5, %v)) { return Parent::useFifthSlot(%v); } }
	function useSixthSlot(%v) { if(!BLTC_PressNumber(6, %v)) { return Parent::useSixthSlot(%v); } }
	function useSeventhSlot(%v) { if(!BLTC_PressNumber(7, %v)) { return Parent::useSeventhSlot(%v); } }
	function useEighthSlot(%v) { if(!BLTC_PressNumber(8, %v)) { return Parent::useEighthSlot(%v); } }

	function BLTC_AnimateInventory(%level, %isGhost)
	{
		%level = mClamp(%level, 0, 2);

		%pos1 = "15 -125";
		%pos2 = "15 -265";

		if(TowerInventory.getGroup().getName() !$= "GuiGroup" && !%isGhost)
			GuiGroup.add(TowerInventory);

		if(%level < 1)
		{
			Canvas.popDialog(TowerInventory);

			BLTC_InventoryTooltip();
		}

		if(%level > 0)
		{
			%pos1 = "15 -45";

			if(!TowerInventory.isAwake() && !%isGhost)
				Canvas.pushDialog(TowerInventory);

			if(TowerInventory.getGroup().getName() !$= "NewChatHUD" && %isGhost)
				NewChatHUD.add(TowerInventory);
		}

		if(%level > 1)
		{
			%pos2 = "15 73";
		}

		%time = 500 * !%isInstant;
		%ease = elastic;

		TowerInventoryBox1.tangoMoveTo(%pos1, %time, %ease);
		TowerInventoryBox2.tangoMoveTo(%pos2, %time, %ease);

		TowerInventory.centerX();
	}

	function BLTC_PressNumber(%num, %down)
	{
		if($TowerBuildingMode)
		{
			return false;
		}

		%num = mClamp(%num, 1, 8);

		$BLTC::UsingSlot = %num;

		BLTC_BuildInventoryGui();

		if(!TowerInventory.isAwake() || TowerInventory.getGroup().getName() $= "NewChatHUD")
			BLTC_AnimateInventory(%down, true);

		return true;
	}

	function BLTC_ClearInventory()
	{
		deleteVariables("$BLTC::Inventory*");

		BLTC_BuildInventoryGui();
	}

	function clientCmdBLT_ClearInventory()
	{
		BLTC_ClearInventory();
	}

	function BLTC_SetInventory(%i, %item, %name, %canPlace)
	{
		%i = mClamp(%i, 1, 32);

		$BLTC::Inventory::ItemID[%i] = %item;
		$BLTC::Inventory::ItemName[%i] = %name; //BLTC_InventoryTooltip
		$BLTC::Inventory::ItemCanPlace[%i] = %canPlace;
	}

	function clientCmdBLT_SetInventory(%i, %item, %name, %canPlace)
	{
		BLTC_SetInventory(%i, %item, %name, %canPlace);
	}

	function BLTC_BuildInventoryGui()
	{
		TowerInventoryGroup1.clear();
		TowerInventoryGroup2.clear();

		for(%i = 1; %i <= 32; %i++)
		{
			%item = $BLTC::Inventory::ItemID[%i];

			%isItem = %item !$= "";

			%name = $BLTC::Inventory::ItemName[%i];

			if(%i > 8)
			{
				%secondary = true;
			}

			if(%secondary)
			{
				if(%c >= 8)
				{
					%y += 70;
					%c = 0;
				}

				%pos = 70 * %c SPC %y;

				%c++;
			}
			else
			{
				%pos = 70 * (%i - 1) SPC 42;
			}

			%gObj = (%secondary ? TowerInventoryGroup2 : TowerInventoryGroup1);

			%gObj.add(new GuiBitmapCtrl("TI_Panel_" @ %i)
			{
				position = %pos;
				extent = "64 63";
				bitmap = (%i == $BLTC::UsingSlot ? "Add-Ons/Client_Blockland_Tower/res/img/panel_i" : "Add-Ons/Client_Blockland_Tower/res/img/panel_n");
			});

			if(%isItem)
			{
				%gObj.add(new GuiBitmapCtrl()
				{
					position = %pos;
					extent = "64 64";
					bitmap = "Add-Ons/Client_Blockland_Tower/res/img/items/" @ %item;
				});
			}

			if(!%secondary)
			{
				%gObj.add(new GuiTextCtrl()
				{
					position = VectorAdd(%pos, "6 -6");
					text = %i;
					profile = BLT_InventoryNumberProfile;
				});
			}

			%gObj.add(new GuiMouseEventCtrl()
			{
				position = %pos;
				extent = "64 63";
				towerInventoryNumber = %i;
			});
		}
	}

	function clientCmdBLT_BuildInventoryGui()
	{
		BLTC_BuildInventoryGui();
	}

	function BLTC_InventoryTooltip(%text)
	{
		cancel($BLTC::InventoryTooltip);

		TowerInventoryTooltipFrame.setVisible(%text !$= "");

		if(%text $= "")
		{
			TowerInventoryTooltipFrame.tangoSetPosition(0, -200);
			return;
		}

		TowerInventoryTooltipText.setText(%text);

		%width = getWord(TowerInventoryTooltipText.getExtent(), 0);

		TowerInventoryTooltipSwatch.resize(8, 8, %width, 18);

		%mouseX = getWord(Canvas.getCursorPos(), 0);
		%mouseY = getWord(Canvas.getCursorPos(), 1);
		TowerInventoryTooltipFrame.resize(%mouseX + 16, %mouseY, %width + 16, 34);

		$BLTC::InventoryTooltip = schedule(33, 0, BLTC_InventoryTooltip, %text);
	}

};

BLTC_RegisterPackage(BLTC_Package_Inventory);
