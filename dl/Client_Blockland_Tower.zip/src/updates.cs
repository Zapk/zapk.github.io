if(!isObject(TowerUpdateChecker))
{
   new HTTPObject(TowerUpdateChecker);
}

function TowerUpdateChecker::checkForUpdates(%this)
{
   %this.checkedVersionString = "";
   %this.get("tower.zapkraft.net:80", "/clientversion.txt");
}

function TowerUpdateChecker::onLine(%this, %line)
{
   %this.checkedVersionString = %line;
   %this.checkedVersionInteger = mFloor(strreplace(%line, ".", ""));
}

function TowerUpdateChecker::onDisconnect(%this)
{
   %version = %this.checkedVersionInteger;
   %vstring = %this.checkedVersionString;
   %current = $BLTC::VersionInteger;

   if(%version $= "")
      return;

   TowerUpdateAvailableVersion.setText("<just:center><font:Oswald ExtraLight:44>" @ %vstring);

   if(%current >= %version)
      return;

   TowerUpdateAvailable.activateNotify();
}

function TowerUpdateAvailable::activateNotify(%this)
{
   if(isObject(TowerUpdateReminder))
   {
      TowerUpdateReminder.delete();
   }

   alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/content/sounds/piano/a36.wav"));
   Canvas.pushDialog(%this);

   TowerUpdateAvailableHeader.tangoSetPosition("19 -100");
   TowerUpdateAvailableHeader.tangoMoveTo("19 30", 2600, elastic);

   TowerUpdateAvailableVersion.tangoSetPosition("19 300");
   TowerUpdateAvailableVersion.tangoMoveTo("19 140", 2600, elastic);
}

function TowerUpdateAvailable::clickNo(%this)
{
   alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/content/sounds/piano/b25.wav"));
   Canvas.popDialog(%this);

   if(isObject(TowerUpdateReminder))
   {
      TowerUpdateReminder.delete();
   }

   new GuiControl(TowerUpdateReminder) {
      horizSizing = "left";
      vertSizing = "top";
      position = "510 350";
      extent = "128 128";

      new GuiBitmapCtrl() {
         horizSizing = "center";
         vertSizing = "center";
         position = "0 31";
         extent = "128 64";
         bitmap = "Add-Ons/Client_Blockland_Tower/res/img/shadow";
      };

      new GuiBitmapButtonCtrl() {
         profile = "BLT_ButtonTextProfile";
         horizSizing = "center";
         vertSizing = "center";
         position = "18 48";
         extent = "91 31";
         command = "TowerUpdateAvailable.activateNotify();";
         text = "Tower Update";
         bitmap = "Add-Ons/Client_blockland_Tower/res/img/btn1";
         mColor = "255 236 220 255";
      };
   };

   MainMenuButtonsGui.add(TowerUpdateReminder);
   TowerUpdateReminder.tangoSetPosition( VectorSub(MainMenuButtonsGui.extent, TowerUpdateReminder.extent) );
}

function TowerUpdateAvailable::clickYes(%this)
{
   alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/content/sounds/piano/a35.wav"));

   Canvas.popDialog(%this);
   TowerUpdateDownloader.downloadUpdate();
}

if(!isObject(TowerUpdateDownloader))
{
   new TCPObject(TowerUpdateDownloader);
}

function TowerUpdateDownloader::downloadUpdate(%this)
{
   %this.textInfo("Connecting...");
   TowerUpdateProgress.resize(0, 0, 0, 38);

   Canvas.pushDialog(TowerUpdating);
   TowerUpdating.downloadingLoop();

   %this.server = "tower.zapkraft.net";
	%this.directory = "/download/Client_Blockland_Tower.zip";
	%this.port = 80;
	%this.outputFile = "config/client/blt/temp.zip";

	%this.connectAttempt = 0;

	%this.connect(%this.server @ ":" @ %this.port);
}

function TowerUpdateDownloader::textInfo(%this, %text)
{
   TowerUpdateText.setText("<font:Oswald:40>" @ %text);
}

function TowerUpdateDownloader::onConnected(%this)
{
   %this.textInfo("Connected...");

   %this.send("GET" SPC %this.directory SPC "HTTP/1.0\r\nHost:" SPC %this.server @ "\r\n\r\n");
}

function TowerUpdateDownloader::onLine(%this, %line)
{
	if(strPos(%line, "Content-Length:") >= 0)
   {
		%this.len = getWord(%line, 1);
   }

	if(%line $= "")
   {
		%this.setBinarySize(%this.len);
   }
}

function TowerUpdating::downloadingLoop(%this)
{
   cancel(%this.downloadingLoop);

   if(!%this.isAwake())
      return;

   %this.periodCount = %this.periodCount++ % 4;

   switch(%this.periodCount)
   {
      case 0: %dots = "";
      case 1: %dots = ".";
      case 2: %dots = "..";
      case 3: %dots = "...";
   }

   TowerUpdateDownloader.textInfo("Downloading" @ %dots);

   %this.downloadingLoop = %this.schedule(333, downloadingLoop);
}

function TowerUpdateDownloader::onBinChunk(%this, %chunk)
{
   %isEnd = mCeil(%chunk) >= mFloor(%this.len);

   echo(%chunk SPC "of" SPC %this.len SPC %isEnd);

	if(%isEnd)
	{
      echo("Done.");
		%this.saveBufferToFile(%this.outputFile);

      %this.schedule(2, onDownloadDone);
	}

   %x = mCeil( (%chunk / %this.len) * 448 );
   TowerUpdateProgress.resize(0, 0, %x, 38);

   TowerUpdateProgressText.setText("<font:Oswald Light:40>" @ mFloatLength(%chunk / 1024 / 1024, 1) @ "/" @ mFloatLength(%this.len / 1024 / 1024, 1) @ " MB");
}

function TowerUpdateDownloader::onConnectFailed(%this)
{
	if(%this.connectAttempt >= 2)
   {
      %this.textInfo("Connection failed!");
      Canvas.popDialog(TowerUpdating);
   }
	else
	{
		%this.connectAttempt++;
		%this.schedule(2000, 0, connect, %this.server @ ":" @ %this.port);
      %this.textInfo("Retrying...");
	}
}

function TowerUpdateDownloader::onDNSFailed(%this)
{
   %this.textInfo("DNS failed!");
   Canvas.popDialog(TowerUpdating);
}

function TowerUpdateDownloader::onDownloadDone(%this)
{
   %mod = "Add-Ons/Client_Blockland_Tower.zip";
   %temp = %this.outputFile;

   if(isFile(%temp))
   {
      if(isFile(%mod))
      {
         fileDelete(%mod);
      }

      fileCopy(%temp, %mod);
   }

   Canvas.popDialog(TowerUpdating);
   TowerUpdateDone.activateNotify();
}

function TowerUpdateDone::activateNotify(%this)
{
   alxPlay(alxCreateSource(AudioGui, "Add-Ons/Client_Blockland_Tower/content/sounds/piano/a26.wav"));
   Canvas.pushDialog(%this);
}

TowerUpdateChecker.schedule(0, checkForUpdates);
